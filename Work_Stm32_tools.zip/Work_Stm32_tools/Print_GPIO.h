//
// Created by 123456 on 2021/6/19.
//

#ifndef WORK_STM32_TOOLS_PRINT_GPIO_H
#define WORK_STM32_TOOLS_PRINT_GPIO_H

#include <iostream>

int print();

#endif //WORK_STM32_TOOLS_PRINT_GPIO_H
