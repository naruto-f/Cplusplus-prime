//
// Created by 123456 on 2021/6/19.
//
#include "CRC.h"
#include "count.h"
#include "Print_GPIO.h"

/*static uint8_t lprobuf[60];
void Task()
{
    uint16_t lCRC;
    static unsigned int ltestnum = 0;

    lCRC = 0;

#if 1
    lprobuf[0] = 0x01;
    lprobuf[1] = 0x03;
    lprobuf[2] = 0x00;
    lprobuf[3] = 0x00; //IO add
    lprobuf[4] = 0x00; //IO on/off
    lprobuf[5] = 0x01;
    //lprobuf[6]=0x02;
    //lprobuf[7]=0xff;
    //lprobuf[8]=0xff;
    //lprobuf[9]=0x55;
    //lprobuf[10]=0x55;
#endif

#if 0
    lprobuf[0]=0x00;
   lprobuf[1]=0x0f;
   lprobuf[2]=0x00;
   lprobuf[3]=0x01;   //IO add
   lprobuf[4]=0x00;		//IO on/off
   lprobuf[5]=0x15;
    lprobuf[6]=0x04;
    lprobuf[7]=0xff;
    lprobuf[8]=0xff;
    lprobuf[9]=0xff;
    lprobuf[10]=0x07;
    *//*lprobuf[11]=0xff;
    lprobuf[12]=0xff;
    lprobuf[13]=0x00;
    lprobuf[14]=0x07;*//*
#endif

    while (ltestnum < 20)
    {
#if 0 ///get CRC
        //lprobuf[3] = ltestnum;
        lCRC = CRC16(lprobuf, 11);
        lprobuf[11] = lCRC & 0x00ff;
        lprobuf[12] = lCRC >> 8;
        for (int i = 0; i < 13; i++)
        {
            printf("%02X ", lprobuf[i]);
        }
        printf("\n");
#endif
#if 1 ///get CRC
        lprobuf[3] = ltestnum;
        lCRC = CRC16(lprobuf, 6);
        lprobuf[6] = lCRC & 0x00ff;
        lprobuf[7] = lCRC >> 8;
        for (int i = 0; i < 8; i++)
        {
            printf("%02X ", lprobuf[i]);
        }
        printf("\n");
#endif
        ltestnum++;
    }
}*/

int main()
{
    //Task();
    std::string os_name = "/mnt/c/Users/123456/CLionProjects/Work_Stm32_tools/ini.txt";
    std::string is_name = "/mnt/c/Users/123456/CLionProjects/Work_Stm32_tools/TEST.txt";
    std::ifstream is(is_name);
    std::ofstream os(os_name);
    count(is, os, "get");

    is.close();
    os.close();
    return 0;
}