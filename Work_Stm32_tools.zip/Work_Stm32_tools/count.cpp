//
// Created by 123456 on 2021/6/19.
//
#include "count.h"

void count(std::ifstream &is, std::ofstream &os, std::string fun)
{
    int i = 101;
    int j = 1;
    int delay = (fun == "get") ? 1000 : 5000;
    std::string s1 = "N";
    std::string s2 = "=";
    std::string s3 = " status";
    std::string s4 = ",";
    std::string s5 = (fun == "get") ? "get sw" : "set sw";
    std::string s6 = "H";
    std::string line;
    while(getline(is, line))
    {
        os << s1 + std::to_string(i++) + s2 + std::to_string(j) + s4 + s5 + std::to_string(j) + s3 + s4 + std::to_string(delay) << std::endl;
        os << s1 + std::to_string(j++) + s2 + s6 + s4 + line << std::endl;
        os << std::endl;
    }
}

/*
int main()
{
    std::string os_name = "/mnt/c/Users/123456/CLionProjects/Work_Stm32_tools/ini.txt";
    std::string is_name = "/mnt/c/Users/123456/CLionProjects/Work_Stm32_tools/TEST.txt";
    std::ifstream is(is_name);
    std::ofstream os(os_name);
    count(is, os, "set");
    is.close();
    os.close();
    return 0;
}
*/

